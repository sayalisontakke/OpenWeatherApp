# Weather-Api-using-django
It is a simple example how to get the weather status for city using Django and SQLite3 database
